"""
File: spellotron_output.py
Version: python3
assignment: project
author: Albin Liang
purpose: A module of spellotron that specifically deals with output for the words argument.
"""

import spellotron



def spell_checker(word, dictionary, key_checker, alphabet):
    """
    spell_checker takes in a word passed from the two mode functions, the american dictionary set, key adj. dictionary
    and the alphabet tuple. It then runs through the spell checks in the order specified.
    :param word: The word to be spell checked
    :param dictionary: Dictionary set
    :param key_checker: Key adjacency dictionary
    :param alphabet: tuple of alphabet letters lowercase
    """
    if not word in dictionary: # if not in the set
        for n in range(len(word)): #go through the index
            if word[n] in key_checker.keys(): #check every letter for adjancency error
                for ch in key_checker[word[n]]:
                    first_part = word[:n]
                    second_part = word[n+1:]
                    pieces = [first_part, second_part]
                    combination = ch.join(pieces)
                    if combination in dictionary:
                        return combination
            else:
                pass #if check fails pass and move to next one

        for n in range(len(word)): #all indexes again
            for ch in alphabet: #check the alphabet inserted at every index position plus 1
                if n+1 == len(word): #if its the last index, add the letter to the end
                    added_letter = word[:n+1] + ch
                    if added_letter in dictionary:
                        return added_letter
                else:# otherwise concat it between the two pieces
                    added_letter = word[:n+1] + ch + word[n+1:]
                    if added_letter in dictionary:
                        return added_letter

        for n in range(len(word)): #check for extra characters
            deleted_letter = word[:n] + word[n + 1:]
            if deleted_letter in dictionary:
                return deleted_letter
    else: #if the word is already in the dictionary set
        return word

def words_out(data, dictionary, key_checker, alphabet):
    """
    words_out takes in the list of words from the input source in the main module. It also takes in the arguments for
    the dictionary set, the key adjacency dictionary, and the tuple of alphabet characters.
    :param data: list of strings
    :param dictionary: set of American words
    :param key_checker: dictionary of keys and their adjacent characters.
    :param alphabet: tuple of the alphabet characters and their adjacent characters
    """
    corrected_words = []
    correct_words = []
    unknown_words = []

    for words in range(len(data)):# go through all the words in the list
        word = data[words]
        pre_punct_mark = ""
        post_punct_mark = ""
        for i in range(len(word)):
            while i == 0 and (word[i] in spellotron.PUNCTUATION): #slice the punctuation in the beginning
                pre_punct_mark += word[i]
                word = word[1:]
                if word == "":#if it is only a special character
                    word = pre_punct_mark #set it back to word
                    break
        while word[len(word)-1] in spellotron.PUNCTUATION: #slice the punctuation at the end
            index = (len(word)-1)
            post_punct_mark += word[len(word)-1]
            word = word[:index]
            if word == "":
                word = post_punct_mark
                break
        punct_less_word = word #word with the leading and trailing punct. marks removed
        if punct_less_word.isdigit():# check if it is a digit
            pass
        elif not punct_less_word in dictionary: #spell check it
            checked_word = spell_checker(punct_less_word, dictionary, key_checker, alphabet)
            if checked_word in dictionary and not(punct_less_word[0].isupper()):
                correct_word = pre_punct_mark + checked_word + post_punct_mark[::-1]
                correct_words.append(correct_word)
                corrected_word = pre_punct_mark + punct_less_word + post_punct_mark[::-1]
                corrected_words.append(corrected_word)
            else:
                if punct_less_word[0].isupper():
                    lower_case_word = punct_less_word[0].lower() + punct_less_word[1:]
                    checked_word = spell_checker(lower_case_word, dictionary, key_checker, alphabet)
                    if lower_case_word == checked_word:
                        pass
                    elif lower_case_word != checked_word and checked_word in dictionary:
                        recapitalized = checked_word[0].upper() + checked_word[1:]
                        correct_word = pre_punct_mark + recapitalized + post_punct_mark[::-1]
                        correct_words.append(correct_word)
                        corrected_words.append(word)
                    else:
                        if pre_punct_mark == post_punct_mark and pre_punct_mark == word:
                            unknown_word = word
                            unknown_words.append(unknown_word)
                        else:
                            unknown_word = pre_punct_mark + word + post_punct_mark[::-1]
                            unknown_words.append(unknown_word)
                else:
                    if pre_punct_mark == post_punct_mark and pre_punct_mark == word:
                        unknown_word = word
                        unknown_words.append(unknown_word)
                    else:
                        unknown_word = pre_punct_mark + word + post_punct_mark[::-1]
                        unknown_words.append(unknown_word)

    return (corrected_words, correct_words, unknown_words)

def lines_out(data, dictionary, key_checker, alphabet):
    """
    lines_out takes in the list of words from the input source in the main module. It also takes in the arguments for
    the dictionary set, the key adjacency dictionary, and the tuple of alphabet characters.
    :param data: list of strings
    :param dictionary: set of American words
    :param key_checker: dictionary of keys and their adjacent characters.
    :param alphabet: tuple of the alphabet characters and their adjacent characters
    """
    corrected_sentence = [] #sentence needs to be recreated with the corrected words, adding them as they get checked
    corrected_words = []
    correct_words = []
    unknown_words = []



    for words in range(len(data)):
        word = data[words]
        pre_punct_mark = ""
        post_punct_mark = ""
        for i in range(len(word)):
            while i == 0 and (word[i] in spellotron.PUNCTUATION):
                pre_punct_mark += word[i]
                word = word[1:]
                if word == "":
                    word = pre_punct_mark
                    break
        while word[len(word)-1] in spellotron.PUNCTUATION:
            index = (len(word)-1)
            post_punct_mark += word[len(word)-1]
            word = word[:index]
            if word == "":
                word = post_punct_mark
                break
        punct_less_word = word
        if punct_less_word.isdigit():
            number = pre_punct_mark + punct_less_word + post_punct_mark[::-1]
            corrected_sentence.append(number)
        elif not punct_less_word in dictionary:
            checked_word = spell_checker(punct_less_word, dictionary, key_checker, alphabet)
            if checked_word in dictionary and not(punct_less_word[0].isupper()):
                correct_word = pre_punct_mark + checked_word + post_punct_mark[::-1]
                correct_words.append(correct_word)
                corrected_word = pre_punct_mark + word + post_punct_mark[::-1]
                corrected_words.append(corrected_word)
                corrected_sentence.append(correct_word)
            else:
                if punct_less_word[0].isupper():
                    lower_case_word = punct_less_word[0].lower() + punct_less_word[1:]
                    checked_word = spell_checker(lower_case_word, dictionary, key_checker, alphabet)
                    if lower_case_word == checked_word:
                        recapitalized = checked_word[0].upper() + checked_word[1:]
                        correct_word = pre_punct_mark + recapitalized + post_punct_mark[::-1]
                        corrected_sentence.append(correct_word)
                    elif lower_case_word != checked_word and checked_word in dictionary:
                        recapitalized = checked_word[0].upper() + checked_word[1:]
                        correct_word = pre_punct_mark + recapitalized + post_punct_mark[::-1]
                        correct_words.append(correct_word)
                        corrected_words.append(word)
                        corrected_sentence.append(correct_word)
                    else:
                        if pre_punct_mark == post_punct_mark and pre_punct_mark == word:
                            unknown_word = word
                            unknown_words.append(unknown_word)
                            corrected_sentence.append(unknown_word)
                        else:
                            unknown_word = pre_punct_mark + word + post_punct_mark[::-1]
                            unknown_words.append(unknown_word)
                            corrected_sentence.append(unknown_word)
                else:
                    if pre_punct_mark == post_punct_mark and pre_punct_mark == word:
                        unknown_word = word
                        unknown_words.append(unknown_word)
                        corrected_sentence.append(unknown_word)
                    else:
                        unknown_word = pre_punct_mark + word + post_punct_mark[::-1]
                        unknown_words.append(unknown_word)
                        corrected_sentence.append(unknown_word)
        else:
            correct_word = pre_punct_mark + punct_less_word + post_punct_mark[::-1]
            corrected_sentence.append(correct_word)

    return (corrected_words, correct_words, unknown_words, corrected_sentence)


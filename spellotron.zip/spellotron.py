"""
File: spellotron.py
Version: python3
assignment: project
author: Albin Liang
purpose: Create a rudimentary spell checker.
"""

import sys
import string
import spellotron_output


LEGAL_WORD_FILE = "american-english.txt" # string of dictionary filename
KEY_ADJACENCY_FILE = "keyboard-letters.txt" #string of key adjacency filename
ALPHABET = tuple(chr(code) for code in range(ord('a'), ord('z')+1)) # tuple containing the alphabet lowercased
PUNCTUATION = tuple(string.punctuation) # a tuple containing all the punctuation marks from string module

def make_dictionary(dict_file):
    """
    make_dictionary takes a filename string and creates a set of every line in the file
    :param dict_file: the filename string
    preconditions: dict_file is a valid filename
    dict_file is in the format of one english word per line.
    """
    american_dictionary = set() # create an empty set
    english_words = open(dict_file, encoding="utf-8")
    line = english_words.readline().strip() # take only the words from each line with no newline characters
    while line != "": # keep going until there is no more
        american_dictionary.add(line) # add the line to the set
        line = english_words.readline().strip() # move to the next line
    return american_dictionary

def make_key_layout(key_file):
    """
    make_key_layout takes a filename string and creates a dictionary of every line in the file with the first character
    being the key and the rest of the characters being the values
    :param key_file: the filename string
    preconditions: key_file is a valid filename
    key_file is in the format of one english alphabet character followed by all other characters adjacent to it on
    a standard keyboard.
    """
    file = open(key_file, encoding="utf-8")
    dt = {}  # create an empty dictionary
    for line in file:  # for every line in the file
        adj_keys = line.split()  # breaks down the lines into individual characters
        key = adj_keys.pop(0) #the key value is the first character in each line
        dt[key] = adj_keys #map the values to the key
    return dt

def remove_dupes_and_sort(lst):
    """
    remove_dupes_and_sort takes a list of words and makes a set containing no duplicates with the words in
    the set, then it sorts the list in place and returns it as a list.
    :param lst: a list of words
    preconditions: a valid list is passed.
    """
    new_set = set()
    new_lst = []
    for elements in lst:
        if not elements in new_set:
            new_set.add(elements)
        else:
            pass
    for words in new_set:
        new_lst.append(words)

    return sorted(new_lst)

if __name__ == '__main__':
    american_dict = make_dictionary(LEGAL_WORD_FILE) #make a set out of the dictionary file
    adjacent_keys = make_key_layout(KEY_ADJACENCY_FILE) #make a dictionary out of the key adj. file
    if not (sys.argv[1] != "words" or sys.argv[1] != "lines"): #if the 1st argument is invalid, raise standard error
        print("Usage: python3.7 spellotron.py words/lines [filename]", file=sys.stderr)
    if len(sys.argv) < 3: #if there is only 2 command line arguments
        text_source = sys.stdin #take the std input as text source
        while True:
            line = text_source.readline()  # Includes the new-line character
            if line != "":  #this will iterate until the EOF input
                word_count = 0 #count starts here
                text_in = line.split() #split the line up into tokens
                word_count += len(text_in) #count the tokens
                if sys.argv[1] == "words": #if mode is words
                    output = spellotron_output.words_out(text_in, american_dict, adjacent_keys, ALPHABET)#tuple of lists
                    corrected_words = output[0]
                    correct_words = output[1]
                    unknown_words = output[2]
                    for i in range(len(correct_words)): # for all the corrected words
                        print(corrected_words[i], "->", correct_words[i]) #print in corrected -> correct format
                    print("")
                    print(word_count, "words read from file.")
                    print("")
                    print(len(corrected_words), "Corrected Words.")
                    sorted_corrected_words = remove_dupes_and_sort(corrected_words)
                    print(sorted_corrected_words)
                    print("")
                    print(len(unknown_words), "Unknown Words.")
                    sorted_unknown_words = remove_dupes_and_sort(unknown_words)
                    print(sorted_unknown_words)
                    print("")
                    print("Input another line or hit enter 'Ctrl' + d to quit.")
                else: #otherwise it is a lines mode argument
                    output = spellotron_output.lines_out(text_in, american_dict, adjacent_keys, ALPHABET)
                    corrected_words = output[0]
                    correct_words = output[1]
                    unknown_words = output[2]
                    corrected_sentence = output[3]
                    print(" ".join(corrected_sentence)) #join the list of the all the words in the corrected sentence
                    print("")
                    print(word_count, "words read from file.")
                    print("")
                    print(len(corrected_words), "Corrected Words.")
                    sorted_corrected_words = remove_dupes_and_sort(corrected_words)
                    print(sorted_corrected_words)
                    print("")
                    print(len(unknown_words), "Unknown Words.")
                    sorted_unknown_words = remove_dupes_and_sort(unknown_words)
                    print(sorted_unknown_words)
                    print("")
                    print("Input another line or hit enter 'Ctrl' + d to quit.")
            else:
                print("Good Bye")
                exit()

    elif len(sys.argv) == 3: #if there are exactly 3 arguments
        text_source = open(sys.argv[2]) #the third argument is the datafile name string
        word_count = 0
        line = text_source.readline() #read the line from the data file
        text_in = []
        while line != "": #keep going until you hit the EOF
            text_in += line.split()
            word_count = len(text_in)
            line = text_source.readline() #go to next line
        if sys.argv[1] == "words": #if words mode
            output = spellotron_output.words_out(text_in, american_dict, adjacent_keys, ALPHABET)
            corrected_words = output[0]
            correct_words = output[1]
            unknown_words = output[2]
            for i in range(len(correct_words)):
                print(corrected_words[i], "->", correct_words[i])
            print("")
            print(word_count, "words read from file.")
            print("")
            print(len(corrected_words), "Corrected Words.")
            sorted_corrected_words = remove_dupes_and_sort(corrected_words)
            print(sorted_corrected_words)
            print("")
            print(len(unknown_words), "Unknown Words.")
            sorted_unknown_words = remove_dupes_and_sort(unknown_words)
            print(sorted_unknown_words)
        else: #otherwise lines mode
            output = spellotron_output.lines_out(text_in, american_dict, adjacent_keys, ALPHABET)
            corrected_words = output[0]
            correct_words = output[1]
            unknown_words = output[2]
            corrected_sentence = output[3]
            print(" ".join(corrected_sentence))
            print("", "")
            print(word_count, "words read from file.")
            print("")
            print(len(corrected_words), "Corrected Words.")
            sorted_corrected_words = remove_dupes_and_sort(corrected_words)
            print(sorted_corrected_words)
            print("")
            print(len(unknown_words), "Unknown Words.")
            sorted_unknown_words = remove_dupes_and_sort(unknown_words)
            print(sorted_unknown_words)
        if text_source != sys.stdin: #close the file read
            text_source.close()
    else:
        print("Usage: python3.7 spellotron.py words/lines [filename]", file=sys.stderr)